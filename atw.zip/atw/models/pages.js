exports.dataPages = function()
{
    var pages = new Array();
    pages['authentification'] = ['Authentification', '../pages/connexion'];
    pages['inscription'] = ['Inscription', '../pages/inscription'];
    pages['home'] = ['Accueil', '../pages/home'];
    pages['profil'] = ['Profil', '../pages/profil'];
    
    return pages;
};


